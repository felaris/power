<?php

/*
 * @CODOLICENSE
 */

namespace CODOF\Booter\IoC;

class I extends IoC{

    
    protected static function getComponentName() {
        
        return 'i';
    }
    
}
