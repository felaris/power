<?php

/* 
 * @CODOLICENSE
 */

defined('IN_CODOF') or die("Not IN_CODOF");

$CF_installed=false;

function get_codo_db_conf() {


    $config = array (
  'driver' => 'mysql',
  'host' => 'localhost',
  'database' => 'codoforum',
  'username' => 'root',
  'password' => 'root',
  'prefix' => '',
  'charset' => 'utf8',
  'collation' => 'utf8_unicode_ci',
);

    return $config;
}

$DB = get_codo_db_conf();

$CONF = array (
    
  'driver' => 'Custom',
  'UID'    => '5a06fd32c2821',
  'SECRET' => '5a06fd32c283f',
  'PREFIX' => ''
);
