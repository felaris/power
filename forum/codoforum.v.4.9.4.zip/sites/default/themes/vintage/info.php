<?php

$info['name'] = 'Vintage';
$info['description'] = 'A traditional theme for the memories';
$info['version'] = '1.x';
$info['author'] = "Codologic";
$info['author_url'] = 'http://codologic.com';
$info['license'] = 'Core License';
$info['core'] = '1.x';
$info['parent_theme'] = 'default';
$info['forum_type'] = 'classic';