<?php
/**
 *
 * User: silva
 * Date: 2019-01-14
 * Time: 20:50
 */

if(!\CODOF\Util::optionExists('FREICHAT_FLOAT_ENABLED')){
    \CODOF\Util::set_opt('FREICHAT_FLOAT_ENABLED', "no");
}


